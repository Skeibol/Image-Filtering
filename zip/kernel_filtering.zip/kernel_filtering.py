import numpy as np
import cv2

def pad_image(img, amount):
    """Paddanje slike da pikseli nebi bili out of range prilikom primjene kernela

    Args:
        img (_type_): Ulazna slika na koju cemo dodati rub radi primjene kernela(range)
        amount (_type_): Kolicina piksela koje cemo dodati na svaku stranu slike (zavisi od velicine kernela)
    """
    h_original,w_original,c_original = img.shape
    
    padded_img = np.zeros((h_original+amount*2,w_original+amount*2,c_original), dtype=np.int16) #stvara matricu prema velicini ulazne slike
    padded_img[amount:h_original+amount,amount:w_original+amount] = img # stavljamo originalnu sliku u prethodnu matricu
    
    
    #PADDING RUBOVA
    for c in range(c_original): #iteriranje kroz kanale
        h,w,_ = padded_img.shape
        padded_img[0:amount,1:-1,c]=padded_img[amount,1:-1,c] #padding gornjih redaka

        padded_img[h-amount:h,amount:w-amount,c] = padded_img[h-amount-1,amount:w-amount,c] #padding donjih redaka

        for amt in range(amount): #For loop radi dodavanja
            padded_img[amount:h-amount,w-amount+amt,c]=padded_img[amount:h-amount,w-amount-1,c]#padding desnog ruba

            padded_img[amount:h-amount,amt,c]=padded_img[amount:h-amount,amount,c]#padding lijevog ruba

    

        #PADDING KUTEVA
        padded_img[0:amount,0:amount,c]=padded_img[amount,amount,c] #gornji lijevi kut

        padded_img[0:amount,w-amount:w,c]=padded_img[amount,w-amount-1,c] #gornji desni kut

        padded_img[h-amount:h,w-amount:w,c]=padded_img[h-amount-1,w-amount-1,c] #donji desni kut

        padded_img[h-amount:,:amount,c]= padded_img[h-amount-1,amount,c] #donji lijevi kut

    padded_img = padded_img.astype(np.uint8)
    return padded_img

def apply_kernel(img,kernel_type="blur"):
    """Funkcija primjenjuje kernel na sliku
    
    Args:
        img (_type_): Ulazna slika na koju cemo primjeniti kernel
        kernel_type (_type_): Kernel koji zelimo primjeniti(zasada samo blur)"""
    
    #Blur kernel (stavite bilo koje vrijednosti molim vas da budu neparne dimenzije)
    if kernel_type=="blur":
        kernel = np.array([[0.0625,0.125,0.0625],
                           [0.125 ,0.25 ,0.125],
                           [0.0625,0.125,0.0625]])




    h,_ = kernel.shape
    pad_amount = h//2 #Cijelobrojno djeljenje dimenzije kernela sa dvojkom nam daje kolicinu piksela koje trebamo dodati na sliku da nebi bili out of range
    padded_img = pad_image(img,pad_amount) #stvaranje paddane slike
    new_img = np.zeros_like(img) #stvaranje nove prazne slike u koju cemo ubacivati filtrirane piksele


    
    
    h,w,channel = new_img.shape
    row=pad_amount #kernel na prosirenoj slici ima pocetnu tocku jednaku kolicini piksela koje smo dodali kada smo obavili pre processing
    
    while row<w+1: #kretanje po pikselima slike
        column=pad_amount
        while column<h+1:
            # multiplikacija kernela sa uzetim komadicem slike
            r = np.multiply(padded_img[row-pad_amount:row+pad_amount+1,column-pad_amount:column+pad_amount+1,0] , kernel).sum() 
            g = np.multiply(padded_img[row-pad_amount:row+pad_amount+1,column-pad_amount:column+pad_amount+1,1] , kernel).sum() 
            b = np.multiply(padded_img[row-pad_amount:row+pad_amount+1,column-pad_amount:column+pad_amount+1,2] , kernel).sum() 
            #pohrana dobivene vrijednosti u kanale nove slike
            new_img[row-pad_amount,column-pad_amount,0] = r
            new_img[row-pad_amount,column-pad_amount,1] = g
            new_img[row-pad_amount,column-pad_amount,2] = b
            column+=1
        
        row+=1

    
    new_img = new_img.astype(np.uint8)
    return new_img


#MAIN

img = cv2.imread("giraffe.jpg")
img = cv2.resize(img,(400,400))

img = apply_kernel(img,"blur")


cv2.namedWindow("img")
cv2.moveWindow("img",40,40)
cv2.imshow("img", img)
cv2.waitKey()
cv2.destroyAllWindows()












"""l_new = np.zeros_like(img)

k = np.array([[1,0,1],
              [0,2,0],
              [1,0,1]]
)

h,w = img.shape
start = 1
mid_row = start
mid_column = start
c=1

while mid_row<h-1:
    mid_column = start
    while mid_column<w-1:
        kernel_in=img[mid_row-1:mid_row+2,mid_column-1:mid_column+2]
        l_new[mid_row-1,mid_column-1] = ((np.multiply(kernel_in,k)).sum())/255
        mid_column+=1
        
        
    mid_row+=1

print(l_new)"""
#for i in l:
#    for i1 in i:
#        kernel_in=l[mid_row-1:mid_row+2,mid_column-1:mid_column+2]
#        mid_column+=1
#        print(kernel_in)
#    mid_row+=1
        



